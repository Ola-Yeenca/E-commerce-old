// Reset search founction
function clearFilters() {
  console.log("Actived!");
  // Clear the filters and reset the form fields
  document.getElementById("filter-form").reset();
}
